//
//  Water_Agri_BWFLCApp.swift
//  Water Agri BWFLC
//
//  Created by STEM MacBook Air 01 on 17/5/2023.
//

import SwiftUI

@main
struct Water_Agri_BWFLCApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
