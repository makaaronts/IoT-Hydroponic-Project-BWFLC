//
//  Notification.swift
//  Water Agri BWFLC
//
//  Created by STEM MacBook Air 01 on 18/5/2023.
//

//import SwiftUI
//import UserNotifications
//
//struct AppNotifications {
//    let notificationId: Int
//    let notificationTitle = "Soil Humidity is too low"
//    let notificationBody = "Please ensure the soil is wet enough"
//
//    func showNotification() {
//        let notificationContent = UNMutableNotificationContent()
//        notificationContent.title = self.notificationTitle
//        notificationContent.body = self.notificationBody
//        notificationContent.sound = UNNotificationSound.default
//
//        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
//        let request = UNNotificationRequest(identifier: self.notificationId, content: notificationContent, trigger: trigger)
//    }
//}
