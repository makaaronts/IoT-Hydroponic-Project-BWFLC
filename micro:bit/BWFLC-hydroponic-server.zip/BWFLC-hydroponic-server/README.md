
> 在 [https://fadeoutmuslight.github.io/bwflc-hydroponic-server/](https://fadeoutmuslight.github.io/bwflc-hydroponic-server/) 打開此頁面

## 作為擴充功能使用

可以在 MakeCode 中將此儲存庫新增為**擴充功能**。

* 開啟 [https://makecode.microbit.org/](https://makecode.microbit.org/)
* 按一下**新專案**
* 按一下工具齒輪選單下的**擴充功能**
* 搜索 **https://github.com/fadeoutmuslight/bwflc-hydroponic-server** 並匯出

## 編輯此專案 ![Build status badge](https://github.com/fadeoutmuslight/bwflc-hydroponic-server/workflows/MakeCode/badge.svg)

編輯 MakeCode 中的儲存庫。

* 開啟 [https://makecode.microbit.org/](https://makecode.microbit.org/)
* 按一下**匯入**，然後按一下**匯入 URL**
* 貼上 **https://github.com/fadeoutmuslight/bwflc-hydroponic-server** 並按一下匯入

## Blocks preview

This image shows the blocks code from the last commit in master.
This image may take a few minutes to refresh.

![A rendered view of the blocks](https://github.com/fadeoutmuslight/bwflc-hydroponic-server/raw/master/.github/makecode/blocks.png)

#### 中繼資料 (用於搜索、渲染)

* for PXT/microbit
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
